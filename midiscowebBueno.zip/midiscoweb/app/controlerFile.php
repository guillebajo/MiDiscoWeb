<?php
// ------------------------------------------------
// Controlador que realiza la gestión de usuarios
// ------------------------------------------------
include_once 'config.php';
include_once 'modeloUser.php';

function ctFileVerFicheros (){
    $ruta = "app/dat/". $_SESSION['user'];
    $ficheros = modeloUserGetFicheros($ruta);
    include_once 'plantilla/verficheros.php';
}

function ctFileSubirFicheros(){
    $msg="";
    $archivo = (isset($_FILES['archivo'])) ? $_FILES['archivo'] : null;
    var_dump($_FILES['archivo']['name']);
    if(!modeloFileSave($_FILES['archivo']['name'])){
        $msg="Error al subir el fichero";
    }
    $ruta = "app/dat/". $_SESSION['user'];
    $ficheros = modeloUserGetFicheros($ruta);
    include_once 'plantilla/verficheros.php';
}

function ctFileBorrarFicheros(){
    if (isset($_GET['file'])){
        $fichero=$_GET['file'];
        modeloFileDel($fichero);
        if(modeloFileDel($fichero)){
            header('Location:index.php?orden=VerFicheros');
        }else{
            $msg="Error al borrar el fichero";
            include_once 'plantilla/verficheros.php';
        }
    }
    
}
?>